function [U, d] = elim_gauss_com_piv(n, A, b)
  for j=1:n-1
    
    # Determinando o pivo
    p = j
    Amax = abs(A(j,j))
    for k = j + 1:n
      if (abs(A(k,j)) > Amax)
        Amax = abs(A(k,j)) 
        p = j
      endif
    endfor 
    
    # troca de linhas se o pivo for diferente
    if(p != j)
      for k = 1: n
        t = A(j,k)
        A(j, K) = A(p, k)
        A(p,k) = t
      endfor
      t = b(j)
      b(j) = b(p)
      b(p) = t
    endif
     
    #Eliminacao de Gauss 
    
  endfor
endfunction
