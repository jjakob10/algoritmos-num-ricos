A = [7 0 -3 5; 0 -1 6 2; 0 0 4 -3; 0 0 0 3];
b = [-9; 12; -3; 5];
n = size(A)(1);
A
b
n

[U, d] = elim_gauss_com_piv(n, U, d);
x

r = d - U * x;
r
